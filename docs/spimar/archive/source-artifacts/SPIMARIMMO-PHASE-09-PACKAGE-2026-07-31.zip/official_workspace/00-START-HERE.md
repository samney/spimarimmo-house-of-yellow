# SPIMARIMMO Official Product Workspace

**Owner:** Samney  
**Workspace version:** 2.8  
**Reconciled on:** 31 July 2026  
**Current state:** Gate 8 approved with carried conditions; Phase 09 prototype/motion/mockups complete and ready for Gate 9 review; House of Yellow staging remains blocked by P0 parity defects

## 1. Purpose

This workspace is the clean control layer for the SPIMARIMMO project. It does not erase the earlier work. It separates authoritative inputs, approved decisions, useful explorations, implementation references, and historical material so the product can continue from one trustworthy source of truth.

The product mission is:

> Transform SPIMARIMMO into an exhibitor-first B2B commercial and credibility platform that proves the value of its international property exhibitions, qualifies commercial opportunities, and supports a separate visitor discovery and registration journey.

The controlling commercial question remains:

> Why should a Moroccan property developer invest several tens of thousands of dirhams to exhibit with SPIMARIMMO?

## 2. Read these files first

1. `00-START-HERE.md` — orientation, state, and reading order.
2. `00-Project-Control/01-SOURCE-HIERARCHY.md` — which source controls which decision.
3. `00-Project-Control/02-WORKSPACE-AUDIT.md` — what exists, what is duplicated, and what is missing.
4. `00-Project-Control/03-DECISION-AND-CONFLICT-REGISTER.md` — approved, superseded, provisional, and open decisions.
5. `00-Project-Control/04-DELIVERABLES-REGISTER.md` — every important artifact and its status.
6. `00-Project-Control/05-EXECUTION-ROADMAP.md` — active tracks, gates, and next work.

## 3. Current truth in one view

| Area | Current status | Meaning |
|---|---|---|
| CTO strategic specification | `AUTHORITATIVE` | Controls the product problem, audience hierarchy, conversion narrative, evidence rule, homepage intent, and delivery constraints |
| Workspace/source audit | `COMPLETED` | Existing Library material, packages, duplicates, and visual waves have been inventoried and reconciled |
| Product foundation and IA | `APPROVED_WORKING_BASELINE` | Release boundary, locale/host architecture, CMS reversibility, conversion semantics, pricing, and search defaults now control the PRD |
| PRD | `APPROVED_AT_GATE_2` | The Release 1 behavior, quality, operations, acceptance, and traceability contract controls downstream work |
| Sitemap and template inventory | `APPROVED_AT_GATE_3` | Canonical hosts/locales, navigation, routes, templates, states, indexation, search, and migration assumptions control downstream UX |
| UX journeys and conversion planning | `APPROVED_AT_GATE_4` | Six public journeys, five operational blueprints, and context/conversion/measurement rules control the wireframes |
| Deterministic wireframes | `APPROVED_WITH_CONDITIONS_AT_GATE_5` | 48 stable targets and 144 states control identity work; moderated validation remains required |
| Visual exploration | `PRODUCED_NOT_APPROVED` | Forty-four images exist across inconsistent waves; latest masters are references, not source design |
| Visual identity | `APPROVED_AT_GATE_6` | `IDT-01A — Signal with Moroccan editorial depth` and the black/gold digital identity control downstream design |
| Design system | `APPROVED_WITH_CARRIED_CONDITIONS_AT_GATE_7` | Tokens, 58 component responsibilities, states, responsive/RTL/accessibility, motion/media, content resilience, implementation governance, and traceability control Phase 08 |
| High-fidelity full-site UI | `APPROVED_WITH_CARRIED_CONDITIONS_AT_GATE_8` | All 48 `HIF`/`UXF` targets and 144 state labels control the prototype and handoff layers |
| Prototype, motion and mockups | `COMPLETE_READY_FOR_GATE_9` | Six prototype contracts, 24 motion contracts, 12 presentation scenes, 16 critical QA cases, and a reviewable interactive prototype are complete |
| House of Yellow foundation | `STAGING_REGISTERED_PARITY_FAILED_P0` | Live preview registered; missing video assets/fallback and staging-indexing controls block approval |
| CMS/CRM | `SPECIFIED_AT_POC_LEVEL` | Functional POC plan exists; production CMS choice and operational integrations remain open |
| SPIMAR implementation | `NOT_AUTHORIZED_TO_START` | Gate 9, technical handoff, repository identity, and reference-foundation parity must pass first |

## 4. Two coordinated work tracks

### Track A — SPIMAR product definition

Source audit -> product foundation/IA -> PRD -> sitemap -> UX journeys -> deterministic wireframes -> identity adaptation -> design system -> high-fidelity UI -> engineering handoff.

### Track B — House of Yellow reference foundation

Freeze current clone -> deploy private staging -> capture reference evidence -> audit discrepancies -> converge parity -> extract reusable tokens/components/motion -> approve foundation.

The tracks may run in parallel, but they meet at one gate:

> House of Yellow foundation accepted + SPIMAR identity/design system approved -> neutral implementation mapping and SPIMAR adaptation.

SPIMAR content must not be mixed into the clone while parity is still being measured.

## 5. Canonical directory

```text
SPIMARIMMO-Official-Project/
  00-START-HERE.md
  00-Project-Control/
  01-Source-and-Governance/
  02-Product-Foundation-and-IA/
  03-PRD-and-Requirements/
  04-Sitemap-and-Content-Model/
  05-UX-Flows-and-Wireframes/
  06-Visual-Identity/
  07-Design-System/
  08-High-Fidelity-UI/
  09-Prototype-Motion-and-Mockups/
  10-Technical-Architecture-and-Handoff/
  11-Implementation-and-QA/
  12-Launch-and-Optimization/
  90-House-of-Yellow-Reference-Foundation/
  99-Archive-and-Explorations/
```

## 6. Immediate active gate

The next official product step is Gate 9 — prototype, motion and mockup approval:

1. traverse the exhibitor, resource/proof, meeting, visitor, recovery and RTL/input-parity contracts;
2. verify that event lifecycle, exhibitor sales and visitor registration stay independent;
3. verify exact click/start/submission/provider/booking/business-outcome language;
4. review `MOT-001`–`MOT-024`, including missing media, provider failure and reduced motion;
5. review mobile, Arabic RTL, closed, delayed, invalid and privacy-safe recovery states;
6. retain fixture/content/provider/user-validation and reference-parity conditions;
7. authorize Phase 10 architecture/handoff without authorizing clone adaptation.

The Phase 09 package is under `09-Prototype-Motion-and-Mockups/`. Phases 05–08 continue to control structure, identity, components, states and high-fidelity treatment.

## 7. External dependency

The House of Yellow deployment is registered at `https://spimarimmo-house-of-yellow.vercel.app/`. The initial live comparison confirms missing local video assets across the sampled routes, no hero poster fallback, and incomplete staging indexing metadata. Repository, branch, commit, and build identity are still required.

The controlling register is `90-House-of-Yellow-Reference-Foundation/00-DEPLOYMENT-AND-PARITY-REGISTER.md`. The clone is not accepted for SPIMAR adaptation until P0 defects and the full route/state/viewport parity gate pass.
